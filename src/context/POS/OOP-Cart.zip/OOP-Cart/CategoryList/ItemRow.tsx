// CategoryList/ItemRow.tsx
import React, { useCallback } from 'react';
import { Stack } from '@mui/material';
import POSHeading from '@/components/POS/Common/POSHeading';
import { t } from 'i18next';
import { formatCurrency } from '@/scenes/POS/Core/pos.utils';
import {
    GetApiProductsListing200ProductsItemProductsItem,
    GetApiProductsListing200ServicesItemServicesItem,
    PostApiSaleBodyDataItemsItemDiscountType,
    PostApiSaleBodyDataItemsItemItemType,
    PostApiSaleBodyDataItemsItemSaleType,
} from '@/shared/api/models';
import { useCart } from '@/context/POS/CartContext';
import { ExtendedSaleItem } from '@/types/CartContext.type';

type AccessKey = 'products' | 'services';
type ProductItem = GetApiProductsListing200ProductsItemProductsItem;
type ServiceItem = GetApiProductsListing200ServicesItemServicesItem;
type RowItem = ProductItem | ServiceItem;

export interface ItemRowProps {
    accesKey: AccessKey;
    item: RowItem;
    asRefund: boolean;
    sellBy?: number | string;
}

function ItemRowInner({ accesKey, item, asRefund, sellBy }: ItemRowProps) {
    const { regularItems, refundItems, addItem, updateItem, addRefundItem, updateRefundItem } = useCart();

    const isProduct = accesKey === 'products';

    const uniqueId = isProduct
        ? asRefund
            ? `refund-product-${(item as ProductItem).id}`
            : (item as ProductItem).id.toString()
        : asRefund
          ? `refund-service-${(item as ServiceItem).id}`
          : (item as ServiceItem).id.toString();

    const currentItems: ExtendedSaleItem[] = asRefund ? refundItems : regularItems;

    const existing = currentItems.find((i) =>
        isProduct ? (i.productId?.toString() ?? '') === uniqueId : (i.serviceId?.toString() ?? '') === uniqueId,
    );

    const handleClick = useCallback(() => {
        if (existing) {
            const idx = currentItems.indexOf(existing);
            const updated = { ...existing, quantity: existing.quantity + 1 };
            if (asRefund) updateRefundItem(idx, updated);
            else updateItem(idx, updated);
            return;
        }

        const priceNum = Number((item as any).price ?? 0);
        const base: ExtendedSaleItem = {
            quantity: 1,
            amount: asRefund ? -Math.abs(priceNum) : priceNum,
            price: asRefund ? -Math.abs(priceNum) : priceNum,
            itemName: (item as any).name ?? '',
            discountAmount: 0,
            discountPercentage: 0,
            discountType: PostApiSaleBodyDataItemsItemDiscountType.VARIABLE_PERCENTAGE,
            discounts: [],
            saleType: asRefund
                ? PostApiSaleBodyDataItemsItemSaleType.RETURN
                : PostApiSaleBodyDataItemsItemSaleType.SALE,
            employeeId: Number(sellBy),
        };

        const newItem: ExtendedSaleItem = isProduct
            ? ({
                  ...base,
                  productId: uniqueId,
                  itemType: PostApiSaleBodyDataItemsItemItemType.PRODUCT,
                  tax: (item as ProductItem).tax,
              } as ExtendedSaleItem)
            : ({
                  ...base,
                  serviceId: Number(uniqueId),
                  itemType: PostApiSaleBodyDataItemsItemItemType.SERVICE,
              } as ExtendedSaleItem);

        if (asRefund) addRefundItem(newItem);
        else addItem(newItem);
    }, [
        existing,
        currentItems,
        asRefund,
        item,
        sellBy,
        updateItem,
        updateRefundItem,
        addItem,
        addRefundItem,
        uniqueId,
        isProduct,
    ]);

    const bg = existing ? (asRefund ? '#ffe6e6' : '#f0f0f099') : 'transparent';
    const borderLeft = existing ? (asRefund ? '4px solid #ff0000' : '4px solid #000') : 'none';

    return (
        <Stack
            onClick={handleClick}
            sx={{
                cursor: 'pointer',
                p: 1,
                '&:hover': { backgroundColor: '#f0f0f099' },
                bgcolor: bg,
                borderLeft,
                borderBottom: '0.5px solid #d2d2d2',
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                gap: 1,
            }}
        >
            <Stack sx={{ width: isProduct ? 'auto' : '90%', overflow: 'hidden' }}>
                <POSHeading
                    text={(item as any).name ?? ''}
                    sx={
                        isProduct
                            ? { fontSize: 14, fontWeight: 600 }
                            : {
                                  fontSize: 14,
                                  fontWeight: 600,
                                  display: '-webkit-box',
                                  WebkitLineClamp: 2,
                                  WebkitBoxOrient: 'vertical',
                                  whiteSpace: 'normal',
                                  overflow: 'wrap',
                                  textOverflow: 'ellipsis',
                              }
                    }
                />
                {!isProduct && (
                    <POSHeading
                        text={(item as ServiceItem).description ?? ''}
                        sx={{
                            fontSize: 14,
                            fontWeight: 400,
                            color: '#666',
                            display: '-webkit-box',
                            WebkitLineClamp: 3,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                        }}
                    />
                )}
            </Stack>

            <Stack direction="column">
                <POSHeading
                    text={`${asRefund ? '-' : ''}${formatCurrency((item as any).price)}`}
                    sx={{
                        fontSize: 14,
                        fontWeight: 400,
                        color: asRefund ? '#ff0000' : 'inherit',
                    }}
                />
                {isProduct ? (
                    <POSHeading
                        text={`${(item as ProductItem).stock ?? 0} ${t('POS.InStock')}`}
                        sx={{ fontSize: 12, fontWeight: 400, color: '#666' }}
                    />
                ) : (
                    <POSHeading
                        text={`${(item as ServiceItem).durationMin ?? 0} ${t('POS.Minutes')}`}
                        sx={{
                            fontSize: 12,
                            fontWeight: 400,
                            color: '#666',
                            whiteSpace: 'nowrap',
                        }}
                    />
                )}
            </Stack>
        </Stack>
    );
}

function itemRowComparator(prev: ItemRowProps, next: ItemRowProps) {
    if (prev.accesKey !== next.accesKey) return false;
    if (prev.asRefund !== next.asRefund) return false;
    if (prev.sellBy !== next.sellBy) return false;

    const prevId = (prev.item as any).id ?? (prev.item as any).name;
    const nextId = (next.item as any).id ?? (next.item as any).name;
    if (String(prevId) !== String(nextId)) return false;

    const prevPrice = (prev.item as any).price ?? 0;
    const nextPrice = (next.item as any).price ?? 0;
    if (prevPrice !== nextPrice) return false;

    const prevName = (prev.item as any).name ?? '';
    const nextName = (next.item as any).name ?? '';
    if (prevName !== nextName) return false;

    const isProduct = prev.accesKey === 'products';
    if (isProduct) {
        if (((prev.item as any).stock ?? 0) !== ((next.item as any).stock ?? 0)) return false;
    } else {
        if (((prev.item as any).durationMin ?? 0) !== ((next.item as any).durationMin ?? 0)) return false;
    }

    return true;
}

export default React.memo(ItemRowInner, itemRowComparator);
