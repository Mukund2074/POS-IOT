// CategoryList/index.tsx
import React from 'react';
import POSAccordion from '@/components/POS/Common/POSAccordion';
import POSHeading from '@/components/POS/Common/POSHeading';
import { GetApiProductsListing200ProductsItem, GetApiProductsListing200ServicesItem } from '@/shared/api/models';
import { useCart } from '@/context/POS/CartContext';
import ItemRow from './ItemRow';

export default function CategoryList({
  category,
  search,
  accesKey,
  asRefund,
  openItemId,
  onExpand,
}: {
  category: GetApiProductsListing200ProductsItem | GetApiProductsListing200ServicesItem;
  search: string;
  accesKey: 'products' | 'services';
  asRefund?: boolean;
  openItemId?: string | null;
  onExpand?: (idx: string | null) => void;
}) {
  const isProductCategory = accesKey === 'products';
  const items = isProductCategory
    ? (category as GetApiProductsListing200ProductsItem).products
    : (category as GetApiProductsListing200ServicesItem).services;

  const { cart } = useCart() as any;

  const title = category.id === '0' ? (isProductCategory ? 'Uncategorized Products' : 'Uncategorized Services') : category.name;

  return (
    <POSAccordion
      key={category.id}
      expanded={openItemId === category.id.toString() || (search?.length ?? 0) > 1}
      onChange={(_, expanded) => onExpand?.(expanded ? category.id.toString() : null)}
      title={<POSHeading sx={{ fontSize: 14, fontWeight: 400, px: 2 }} text={title} />}
      sx={{
        p: 0,
        width: '100%',
        m: 0,
        '&.Mui-expanded': { m: 0, p: 0 },
      }}
      summarySx={{
        borderBottom: '1px solid #d2d2d2',
        backgroundColor: '#f0f0f099',
        p: 0,
        px: 2,
        m: 0,
      }}
      detailsSx={{ p: 0, m: 0 }}
    >
      {Array.isArray(items) &&
        items.map((it) => (
          <ItemRow key={(it as any).id} accesKey={accesKey} item={it as any} asRefund={!!asRefund} sellBy={cart?.sellBy} />
        ))}
    </POSAccordion>
  );
}
