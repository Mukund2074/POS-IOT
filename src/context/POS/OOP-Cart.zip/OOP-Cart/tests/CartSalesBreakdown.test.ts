// tests/CartSalesBreakdown.test.ts

import CartSalesBreakdown from "../services/CartSalesBreakdown";

describe('CartSalesBreakdown', () => {
  test('computes product and service totals', () => {
    const items: any[] = [
      { productId: '1', amount: 100, taxes: [], itemType: 'PRODUCT' },
      { serviceId: '2', amount: 50, taxes: [], itemType: 'SERVICE' },
      { productId: '3', amount: -20, taxes: [], itemType: 'PRODUCT' }, // refund
    ];
    const payments: any[] = [{ paymentType: 'CASH_CREDIT', amount: 30 }];
    const b = new CartSalesBreakdown(items, payments).compute();
    expect(b.productSale).toBe(80); // 100 + (-20)
    expect(b.serviceSale).toBe(50);
    expect(b.cashCredit).toBe(30);
  });
});
