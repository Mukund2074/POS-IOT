// tests/CartCalculator.test.ts
import { ExtendedSaleItem } from '@/types/CartContext.type';
import CartCalculator from '../services/CartCalculator';

describe('CartCalculator', () => {
  test('processItems computes totals for simple items', () => {
    const items: ExtendedSaleItem[] = [
      { price: 100, quantity: 2, discountAmount: 0, discountPercentage: 0, discountType: 'VARIABLE_PERCENTAGE' } as any,
    ];
    const refunds: ExtendedSaleItem[] = [];
    const res = CartCalculator.processItems(items, refunds, [], 0, 0, 0);
    expect(res.subTotal).toBe(200);
    expect(res.totalDiscounts).toBe(0);
    expect(res.netTotal).toBe(200);
    expect(res.processedItems.length).toBe(1);
  });

  test('processItems handles refunds correctly', () => {
    const items: ExtendedSaleItem[] = [];
    const refunds: ExtendedSaleItem[] = [{ price: -50, quantity: 1, discountAmount: 0, discountPercentage: 0, discountType: 'VARIABLE_PERCENTAGE' } as any];
    const res = CartCalculator.processItems(items, refunds, [], 0, 0, 0);
    expect(res.subTotal).toBe(-50);
    expect(res.netTotal).toBe(-50);
    expect(res.salesType).toBe('RETURN');
  });
});
