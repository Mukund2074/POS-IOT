// tests/CartService.test.ts
import { PostApiSaleBodyDataItemsItem } from '@/shared/api/models';
import CartService from '../services/CartService';

describe('CartService', () => {
  const emptyState = { rawItems: [], rawRefundItems: [], payments: [] };

  test('addItem adds item to rawItems immutably', () => {
    const item: PostApiSaleBodyDataItemsItem = { price: 100, quantity: 1, amount: 100 } as any;
    const { rawItems } = CartService.addItem(emptyState, item);
    expect(rawItems.length).toBe(1);
    expect(rawItems[0].price).toBe(100);
  });

  test('addRefundItem adds item to rawRefundItems', () => {
    const item: PostApiSaleBodyDataItemsItem = { price: -50, quantity: 1 } as any;
    const { rawRefundItems } = CartService.addRefundItem(emptyState, item);
    expect(rawRefundItems.length).toBe(1);
    expect(rawRefundItems[0].price).toBe(-50);
  });

  test('updateItem updates existing index and preserves addedAt', () => {
    const item: PostApiSaleBodyDataItemsItem = { price: 100, quantity: 1 } as any;
    const s1 = CartService.addItem(emptyState, item);
    const updated = CartService.updateItem(s1, 0, { price: 150, quantity: 1 } as any);
    expect(updated.rawItems[0].price).toBe(150);
  });

  test('addPayment prevents overpay', () => {
    const state = { rawItems: [], rawRefundItems: [], payments: [] };
    const result = CartService.addPayment(state, { paymentType: 'CASH', amount: 500 } as any, 100);
    expect(result.ok).toBe(false);
  });

  test('addPayment allows valid payment', () => {
    const state = { rawItems: [], rawRefundItems: [], payments: [] };
    const result = CartService.addPayment(state, { paymentType: 'CASH', amount: 50 } as any, 100);
    expect(result.ok).toBe(true);
    expect(result.state.payments.length).toBe(1);
  });
});
