// tests/CartPaymentBreakdown.test.ts

import CartPaymentBreakdown from "../services/CartPaymentBreakdown";

describe('CartPaymentBreakdown', () => {
  test('computes basic breakdown', () => {
    const payments: any[] = [
      { paymentType: 'CASH', amount: 100 },
      { paymentType: 'CARD', amount: 50 },
      { paymentType: 'GIFT_CARD', amount: 20 },
    ];
    const b = new CartPaymentBreakdown(payments).compute();
    expect(b.cashAmount).toBe(100);
    expect(b.cardAmount).toBe(50);
    expect(b.giftCardAmount).toBe(20);
  });
});
