// context/CartProvider.tsx
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import moment from 'moment';
import { api } from '@/utils/Api/POS';
import { usePreviousSales } from '@/hooks/api/pos/sales';
import { PostApiSaleBodyDataItemsItem, PostApiSaleBodyDataPaymentItem, GetApiTax200Item } from '@/shared/api/models';
import { ExtendedSaleItem } from '@/types/CartContext.type';
import CartService, { ItemsState } from '../services/CartService';
import CartCalculator from '../services/CartCalculator';
import CartPaymentBreakdown from '../services/CartPaymentBreakdown';
import CartSalesBreakdown from '../services/CartSalesBreakdown';
import { CartOverride } from '../../CartContext';

export const defaultCart: CartOverride = {
    customerId: null,
    customerName: '',
    subTotal: 0,
    totalTax: 0,
    netTotal: 0,
    tenderAmount: 0,
    change: 0,
    roundOff: 0,
    tips: 0,
    salesNote: '',
    salesType: 'SALES',
    sellBy: Number(localStorage.getItem('employee_id')),
    salesDiscounts: [],
    salesTaxes: [],
    salesDate: moment().format('YYYY-MM-DD HH:mm:ss'),
    items: [],
    payment: [],
};

const CartContext = createContext({} as any);

export const CartProvider = ({ children }: React.PropsWithChildren) => {
    const [cart, setCart] = useState<CartOverride>(defaultCart);
    const [rawItems, setRawItems] = useState<ExtendedSaleItem[]>([]);
    const [rawRefundItems, setRawRefundItems] = useState<ExtendedSaleItem[]>([]);
    const [payments, setPayments] = useState<PostApiSaleBodyDataPaymentItem[]>([]);
    const [loading, setLoading] = useState(false);
    const [taxList, setTaxList] = useState<GetApiTax200Item[]>([]);
    const serviceRef = useRef(CartService);
    const calculatorRef = useRef(CartCalculator);

    useEffect(() => {
        let mounted = true;
        (async () => {
            try {
                const resp = await api.getApiTax();
                if (mounted && resp) setTaxList(resp);
            } catch (err) {
                console.error(err);
            }
        })();
        return () => {
            mounted = false;
        };
    }, []);

    const previousSalesQuery = usePreviousSales({
        customerId: cart.customerId ?? null,
        params: { showDeleted: false, limit: 10000 },
        enabled: !!cart.customerId,
    });

    const addItem = (item: PostApiSaleBodyDataItemsItem, index?: number) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = serviceRef.current.addItem(state, item, index ?? 0);
        setRawItems(res.rawItems);
    };

    const addRefundItem = (item: PostApiSaleBodyDataItemsItem, index?: number) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = serviceRef.current.addRefundItem(state, item, index ?? 0);
        setRawRefundItems(res.rawRefundItems);
    };

    const removeItem = (index: number) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = CartService.removeItem(state, index);
        setRawItems(res.rawItems);
    };

    const removeRefundItem = (index: number) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = CartService.removeRefundItem(state, index);
        setRawRefundItems(res.rawRefundItems);
    };

    const updateItem = (index: number, item: PostApiSaleBodyDataItemsItem) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = serviceRef.current.updateItem(state, index, item);
        setRawItems(res.rawItems);
    };

    const updateRefundItem = (index: number, item: PostApiSaleBodyDataItemsItem) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = serviceRef.current.updateRefundItem(state, index, item);
        setRawRefundItems(res.rawRefundItems);
    };

    const addPayment = (payment: Omit<PostApiSaleBodyDataPaymentItem, 'paymentId'>) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const calc = calculatorRef.current.processItems(
            rawItems,
            rawRefundItems,
            taxList || [],
            cart.roundOff ?? 0,
            cart.tips ?? 0,
            cart.paidAmount ?? 0,
        );
        const { ok, state: newState } = serviceRef.current.addPayment(state, payment, calc.netTotal);
        if (ok) setPayments(newState.payments);
        return ok;
    };

    const removePayment = (index: number) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = CartService.removePayment(state, index);
        setPayments(res.payments);
    };

    const updatePayment = (index: number, payment: PostApiSaleBodyDataPaymentItem) => {
        const state: ItemsState = { rawItems, rawRefundItems, payments };
        const res = CartService.updatePayment(state, index, payment);
        setPayments(res.payments);
    };

    const clearPayments = () => setPayments([]);
    const setPaymentsFn = (p: PostApiSaleBodyDataPaymentItem[]) => setPayments(p);

    const clearCart = () => {
        setRawItems([]);
        setRawRefundItems([]);
        setPayments([]);
        setCart(defaultCart);
    };

    const clearRefundItems = () => setRawRefundItems([]);

    const getItem = (index: number, all = false) => (all ? rawItems : rawItems[index]);
    const getRefundItem = (index: number, all = false) => (all ? rawRefundItems : rawRefundItems[index]);
    const getAllItems = () => [...rawItems, ...rawRefundItems];

    const calculateCart = () => {
        const result = calculatorRef.current.processItems(
            rawItems,
            rawRefundItems,
            taxList || [],
            cart.roundOff ?? 0,
            cart.tips ?? 0,
            cart.paidAmount ?? 0,
        );
        setCart((prev) => ({
            ...prev,
            items: result.processedItems,
            subTotal: result.subTotal,
            totalTax: result.totalTax,
            netTotal: result.netTotal,
            totalDiscount: result.totalDiscount,
            salesType: result.salesType,
        }));
    };

    useEffect(() => {
        calculateCart();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [rawItems, rawRefundItems, payments, cart.roundOff, cart.tips, cart.paidAmount, taxList]);

    const paymentBreakdown = useMemo(() => {
        return new CartPaymentBreakdown(cart.payment || []).compute();
    }, [cart.payment]);

    const salesBreakdown = useMemo(() => {
        return new CartSalesBreakdown(cart.items || [], cart.payment || []).compute();
    }, [cart.items, cart.payment]);

    const calculateSalesDiscounts = () => {
        const itemDiscounts = (cart.items || [])
            .filter((item: any) => item.discounts && item.discounts.length > 0)
            .flatMap((item: any) => item.discounts || []);
        return itemDiscounts;
    };

    const removeExtraKeysFromItems = (id: string) => {
        if (!id || id.trim() === '') return null;
        if (id.includes('refund')) return id.replace(/^(refund-product-|product-refund-|refund-service-)/, '');
        if (id.startsWith('product-')) return id.replace(/^product-/, '');
        if (id.startsWith('service-')) return id.replace(/^service-/, '');
        if (id.startsWith('custom')) return null;
        return id;
    };

    const calculateTotalDiscount = () =>
        (cart.items || []).reduce((acc: number, it: any) => acc + (it.discountAmount || 0), 0);

    const calculateSalesTaxes = () => {
        const newItems = (cart.items || []).map((it: ExtendedSaleItem) => {
            const taxes = CartCalculator.calculateItemTaxes(it, taxList || []);
            const taxAmount = taxes.reduce((s, t) => s + (t.taxAmount || 0), 0);
            return { ...it, taxes, taxAmount };
        });
        setCart((prev) => ({ ...prev, items: newItems }));
        return newItems.flatMap((it) => it.taxes || []).filter((t) => (t?.taxAmount || 0) > 0);
    };

    const getCartForSubmission = () => {
        const updatedItems = (cart.items || []).map((it: ExtendedSaleItem) => {
            const cleanProductId = removeExtraKeysFromItems(it.productId?.toString?.() ?? '');
            const cleanServiceId = removeExtraKeysFromItems(it.serviceId?.toString?.() ?? '');
            const { servId, productId, serviceId, uniqueId, ...rest } = it as any;
            return {
                ...rest,
                amount: it.amount,
                subTotal: it.subTotal || 0,
                productId: cleanProductId,
                serviceId: typeof serviceId === 'number' ? serviceId : cleanServiceId,
            };
        });

        const tenderAmount = (cart.payment || []).reduce((s, p) => s + (p.amount || 0), 0);
        const change = Math.max(0, tenderAmount - cart.netTotal);

        const { customer, ...restCart } = cart;

        return {
            ...restCart,
            items: updatedItems,
            salesDate: new Date(moment(cart.salesDate).format('YYYY-MM-DD HH:mm:ss')),
            salesDiscounts: calculateSalesDiscounts(),
            totalDiscount: calculateTotalDiscount(),
            salesTaxes: calculateSalesTaxes(),
            totalTax: cart.totalTax,
            netTotal: cart.netTotal,
            tenderAmount,
            subTotal: cart.subTotal,
            change: cart.salesType === 'RETURN' ? 0 : change,
            salesType: cart.salesType || 'SALES',
        };
    };

    const memoRegularItems = useMemo(
        () => rawItems.map(({ addedAt, uniqueId, ...rest }) => ({ ...rest, uniqueId })),
        [rawItems],
    );
    const memoRefundItems = useMemo(
        () => rawRefundItems.map(({ addedAt, uniqueId, ...rest }) => ({ ...rest, uniqueId })),
        [rawRefundItems],
    );

    const providerValue = useMemo(
        () => ({
            cart,
            setCart,
            loading,
            setLoading,
            addItem,
            removeItem,
            updateItem,
            getItem,
            addRefundItem,
            removeRefundItem,
            updateRefundItem,
            getRefundItem,
            clearRefundItems,
            getAllItems,
            addPayment,
            removePayment,
            updatePayment,
            clearPayments,
            setPayments: setPaymentsFn,
            clearCart,
            getCartForSubmission,
            paymentBreakdown,
            salesBreakdown,
            regularItems: memoRegularItems,
            refundItems: memoRefundItems,
            previousSalesQuery,
            calculateTotalDiscount,
        }),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [
            cart,
            loading,
            rawItems,
            rawRefundItems,
            payments,
            previousSalesQuery,
            memoRegularItems,
            memoRefundItems,
            paymentBreakdown,
            salesBreakdown,
        ],
    );

    return <CartContext.Provider value={providerValue}>{children}</CartContext.Provider>;
};

export const useCart = () => useContext(CartContext);
