// services/CartService.ts
import {
  PostApiSaleBodyDataItemsItem,
  PostApiSaleBodyDataPaymentItem,
} from '@/shared/api/models';
import { ExtendedSaleItem } from '@/types/CartContext.type';

export type ItemsState = {
  rawItems: ExtendedSaleItem[];
  rawRefundItems: ExtendedSaleItem[];
  payments: PostApiSaleBodyDataPaymentItem[];
};

export default class CartService {
  static addItem(state: ItemsState, item: PostApiSaleBodyDataItemsItem, offset = 0): ItemsState {
    const ts = Date.now() + offset;
    const extended: ExtendedSaleItem = {
      ...(item as ExtendedSaleItem),
      addedAt: ts,
      subTotal: (item.price || 0) * (item.quantity ?? 1),
    };
    return { ...state, rawItems: [...state.rawItems, extended] };
  }

  static addRefundItem(state: ItemsState, item: PostApiSaleBodyDataItemsItem, offset = 0): ItemsState {
    const ts = Date.now() + offset;
    const extended: ExtendedSaleItem = {
      ...(item as ExtendedSaleItem),
      addedAt: ts,
      subTotal: (item.price || 0) * (item.quantity ?? 1),
    };
    return { ...state, rawRefundItems: [...state.rawRefundItems, extended] };
  }

  static updateItem(state: ItemsState, index: number, item: PostApiSaleBodyDataItemsItem): ItemsState {
    if (index < 0 || index >= state.rawItems.length) return state;
    const arr = state.rawItems.slice();
    const existing = arr[index];
    arr[index] = {
      ...(item as ExtendedSaleItem),
      addedAt: existing.addedAt,
      subTotal: (item.price || 0) * (item.quantity ?? 1),
    };
    return { ...state, rawItems: arr };
  }

  static updateRefundItem(state: ItemsState, index: number, item: PostApiSaleBodyDataItemsItem): ItemsState {
    if (index < 0 || index >= state.rawRefundItems.length) return state;
    const arr = state.rawRefundItems.slice();
    const existing = arr[index];
    arr[index] = {
      ...(item as ExtendedSaleItem),
      addedAt: existing.addedAt,
      subTotal: (item.price || 0) * (item.quantity ?? 1),
    };
    return { ...state, rawRefundItems: arr };
  }

  static removeItem(state: ItemsState, index: number): ItemsState {
    return { ...state, rawItems: state.rawItems.filter((_, i) => i !== index) };
  }

  static removeRefundItem(state: ItemsState, index: number): ItemsState {
    return { ...state, rawRefundItems: state.rawRefundItems.filter((_, i) => i !== index) };
  }

  static addPayment(
    state: ItemsState,
    payment: Omit<PostApiSaleBodyDataPaymentItem, 'paymentId'>,
    netTotal: number,
  ): { ok: boolean; state: ItemsState } {
    const paid = state.payments.reduce((s, p) => s + (p.amount || 0), 0);
    const remaining = netTotal - paid;
    if ((payment.amount || 0) > remaining) {
      return { ok: false, state };
    }
    const newPayment = { ...payment, paymentId: null, amount: payment.amount, tenderAmount: payment.amount };
    return { ok: true, state: { ...state, payments: [...state.payments, newPayment] } };
  }

  static updatePayment(state: ItemsState, index: number, payment: PostApiSaleBodyDataPaymentItem): ItemsState {
    if (index < 0 || index >= state.payments.length) return state;
    const arr = state.payments.slice();
    arr[index] = { ...payment };
    return { ...state, payments: arr };
  }

  static removePayment(state: ItemsState, index: number): ItemsState {
    return { ...state, payments: state.payments.filter((_, i) => i !== index) };
  }
}
