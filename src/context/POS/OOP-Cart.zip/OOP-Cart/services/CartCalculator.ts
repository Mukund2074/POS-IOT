// services/CartCalculator.ts
import { GetApiTax200Item } from '@/shared/api/models';
import { ExtendedSaleItem } from '@/types/CartContext.type';
import { calculateItemDiscount } from '@/utils/POS/Functions';

export type CartCalculationResult = {
  processedItems: ExtendedSaleItem[];
  subTotal: number;
  totalDiscounts: number;
  totalTax: number;
  netTotal: number;
  totalDiscount: number;
  salesType: 'SALES' | 'RETURN';
};

export default class CartCalculator {
  static calculateItemTaxes(item: ExtendedSaleItem, taxList: GetApiTax200Item[] = []) {
    if (!item || !item.subTotal || !taxList?.length) return [];
    return taxList
      .filter((tax) => tax?.isActive && tax?.applyTaxTo === 'ALL_ITEMS_SERVICES' && item.tax?.includes(tax.id))
      .map((tax) => {
        let taxAmount = 0;
        if (tax.taxType === 'PERCENTAGE') taxAmount = ((item.price ?? 0) * tax.taxRate) / 100;
        else taxAmount = tax.taxRate;
        return {
          taxId: tax.id,
          taxName: tax.taxName,
          taxRate: tax.taxRate,
          taxAmount: parseFloat((taxAmount * (item.quantity ?? 1)).toFixed(2)),
          includeTaxInItemPrice: tax.includeTaxInItemPrice,
          isInclusive: tax.includeTaxInItemPrice,
        };
      });
  }

  static processItems(
    rawItems: ExtendedSaleItem[],
    rawRefunds: ExtendedSaleItem[],
    taxList: GetApiTax200Item[] = [],
    roundOff = 0,
    tips = 0,
    paidAmount = 0,
  ): CartCalculationResult {
    const procRegular = rawItems.map((item) => {
      const subTotal = (item.price ?? 0) * (item.quantity ?? 1);
      const discountAmount = calculateItemDiscount(item);
      const taxes = this.calculateItemTaxes(item, taxList);
      const taxAmount = taxes.reduce((s, t) => s + (t.taxAmount || 0), 0);
      const discounts = [];
      if (item.discountAmount && item.discountAmount > 0) {
        discounts.push({
          discountId: null,
          couponId: null,
          discountName: item.discountType === 'VARIABLE_PERCENTAGE' ? 'Percentage Discount' : 'Amount Discount',
          discountAmount,
          amountType: item.discountType,
          percentage: item.discountType === 'VARIABLE_PERCENTAGE' ? item.discountPercentage : 0,
          amount: item.discountType === 'VARIABLE_PERCENTAGE' ? discountAmount : item.discountAmount,
        });
      }
      return { ...item, subTotal, discountAmount, amount: subTotal - discountAmount, discounts, taxes, taxAmount };
    });

    const procRefunds = rawRefunds.map((item) => {
      const subTotal = (item.price ?? 0) * (item.quantity ?? 1);
      const discountAmount = calculateItemDiscount(item);
      const taxes = this.calculateItemTaxes(item, taxList);
      const taxAmount = taxes.reduce((s, t) => s + (t.taxAmount || 0), 0);
      const discounts = [];
      if (item.discountAmount && item.discountAmount > 0) {
        discounts.push({
          discountId: null,
          couponId: null,
          discountName: item.discountType === 'VARIABLE_PERCENTAGE' ? 'Percentage Discount' : 'Amount Discount',
          discountAmount,
          amountType: item.discountType,
          amount: item.discountType === 'VARIABLE_PERCENTAGE' ? discountAmount : item.discountAmount,
        });
      }
      return {
        ...item,
        taxes,
        taxAmount,
        subTotal,
        discountAmount,
        amount: subTotal < 0 ? subTotal + discountAmount : subTotal - discountAmount,
        discounts,
      };
    });

    const all = [...procRegular, ...procRefunds].sort((a, b) => (a.addedAt || 0) - (b.addedAt || 0)).map(({ addedAt, ...rest }) => rest as ExtendedSaleItem);

    const subTotal = all.reduce((s, it) => s + (it.subTotal ?? 0), 0);
    const totalDiscounts = all.reduce((s, it) => s + (it.discountAmount ?? 0), 0);
    const totalTax = all.reduce((s, it) => s + (it.taxAmount ?? 0), 0);
    const netTotal = subTotal - totalDiscounts + roundOff + tips - paidAmount;

    return {
      processedItems: all,
      subTotal,
      totalDiscounts,
      totalTax,
      netTotal,
      totalDiscount: totalDiscounts,
      salesType: netTotal < 0 ? 'RETURN' : 'SALES',
    };
  }
}
