// services/CartSalesBreakdown.ts
import { PostApiSaleBodyDataPaymentItem } from '@/shared/api/models';
import { ExtendedSaleItem } from '@/types/CartContext.type';

export type SalesBreakdown = {
  productSale: number;
  serviceSale: number;
  giftCardSale: number;
  cutCardSale: number;
  productSaleTaxable: number;
  productSaleNonTaxable: number;
  serviceSaleTaxable: number;
  serviceSaleNonTaxable: number;
  cashCredit: number;
  cardCredit: number;
  bankTransferCredit: number;
  mobilePayCredit: number;
};

export default class CartSalesBreakdown {
  items: ExtendedSaleItem[];
  payments: PostApiSaleBodyDataPaymentItem[];

  constructor(items: ExtendedSaleItem[] = [], payments: PostApiSaleBodyDataPaymentItem[] = []) {
    this.items = items;
    this.payments = payments;
  }

  compute(): SalesBreakdown {
    const breakdown: SalesBreakdown = {
      productSale: 0,
      serviceSale: 0,
      giftCardSale: 0,
      cutCardSale: 0,
      productSaleTaxable: 0,
      productSaleNonTaxable: 0,
      serviceSaleTaxable: 0,
      serviceSaleNonTaxable: 0,
      cashCredit: 0,
      cardCredit: 0,
      bankTransferCredit: 0,
      mobilePayCredit: 0,
    };

    this.items.forEach((item) => {
      const netAmount = item.amount || 0;
      const isRefund = netAmount < 0;
      const hasTaxes = (item.taxes || []).length > 0;

      if (item.productId) {
        breakdown.productSale += netAmount;
        if (!isRefund) {
          if (hasTaxes) breakdown.productSaleTaxable += netAmount;
          else breakdown.productSaleNonTaxable += netAmount;
        }
      } else if (item.serviceId) {
        breakdown.serviceSale += netAmount;
        if (!isRefund) {
          if (hasTaxes) breakdown.serviceSaleTaxable += netAmount;
          else breakdown.serviceSaleNonTaxable += netAmount;
        }
      }

      if ((item.itemType as any) === 'GIFT_CARD') {
        breakdown.giftCardSale += netAmount;
      }
      if ((item.itemType as any) === 'CUT_CARD') {
        breakdown.cutCardSale += netAmount;
      }
    });

    this.payments.forEach((p) => {
      const amt = p.amount || 0;
      switch (p.paymentType) {
        case 'CASH_CREDIT':
          breakdown.cashCredit += amt;
          break;
        case 'CARD_CREDIT':
          breakdown.cardCredit += amt;
          break;
        case 'BANK_TRANSFER_CREDIT':
          breakdown.bankTransferCredit += amt;
          break;
        case 'MOBILE_PAY_CREDIT':
          breakdown.mobilePayCredit += amt;
          break;
        default:
          break;
      }
    });

    return breakdown;
  }
}
