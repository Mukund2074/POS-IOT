// services/CartPaymentBreakdown.ts
import { PostApiSaleBodyDataPaymentItem } from '@/shared/api/models';

export type PaymentBreakdown = {
    cashAmount: number;
    cardAmount: number;
    mobilePayAmount: number;
    bankTransferAmount: number;
    creditAmount: number;
    otherAmount: number;
    outstandingAmount: number;
    paidOutstandingAmount: number;
    giftCardAmount: number;
    bonusAmount: number;
};

export default class CartPaymentBreakdown {
    payments: PostApiSaleBodyDataPaymentItem[];

    constructor(payments: PostApiSaleBodyDataPaymentItem[] = []) {
        this.payments = payments;
    }

    compute(): PaymentBreakdown {
        const breakdown: PaymentBreakdown = {
            cashAmount: 0,
            cardAmount: 0,
            mobilePayAmount: 0,
            bankTransferAmount: 0,
            creditAmount: 0,
            otherAmount: 0,
            outstandingAmount: 0,
            paidOutstandingAmount: 0,
            giftCardAmount: 0,
            bonusAmount: 0,
        };

        this.payments.forEach((p) => {
            const amount = p.amount || 0;
            switch (p.paymentType) {
                case 'CASH':
                    breakdown.cashAmount += amount;
                    break;
                case 'CARD':
                    breakdown.cardAmount += amount;
                    break;
                case 'MOBILE_PAY':
                    breakdown.mobilePayAmount += amount;
                    break;
                case 'BANK_TRANSFER':
                    breakdown.bankTransferAmount += amount;
                    break;
                case 'OUTSTANDING':
                    breakdown.outstandingAmount += amount;
                    break;
                case 'OTHER':
                    breakdown.otherAmount += amount;
                    break;
                case 'GIFT_CARD':
                    breakdown.giftCardAmount += amount;
                    break;
                // case 'CREDIT':
                //   breakdown.creditAmount += amount;
                //   break;
                default:
                    breakdown.otherAmount += amount;
            }
        });

        return breakdown;
    }
}
